# Link4-us

## Getting Started

- install package : `npm ci`  
- run project : `npm run dev`  
- open [http://localhost:3000](http://localhost:3000)

## scripts

`npm dev` -> start local project  
`npm build` -> build project
`npm start` -> start project (after build)


## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.  
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.