export const defaultImageBookmark = "/media/images/default-image-link.png";
