import CreateBookmark from "@/components/specific/Bookmark/CreateBookmark";

export default function CreateBookmarkPage() {
  return <CreateBookmark />;
}
