import Admin from "@/components/specific/Admin";

const AdminPage = () => {
  return (
    <div>
      <Admin />
    </div>
  );
};

export default AdminPage;
